package com.mdellosa.pcourier;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
